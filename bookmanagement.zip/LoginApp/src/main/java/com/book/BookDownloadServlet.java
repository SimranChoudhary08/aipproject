package com.book;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;

public class BookDownloadServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        int bookId = Integer.parseInt(req.getParameter("id"));

        res.setContentType("application/pdf");
        res.setHeader("Content-Disposition", "attachment; filename=book_" + bookId + ".pdf");

        HttpSession session = req.getSession(false);
        String downloadedBy = "Unknown";

        if (session != null) {
            String role = (String) session.getAttribute("role");
            if ("admin".equals(role)) {
                downloadedBy = (String) session.getAttribute("adminName");
            } else if ("user".equals(role)) {
                downloadedBy = (String) session.getAttribute("username");
            }
        }

        Document document = new Document();
        try {
            PdfWriter.getInstance(document, res.getOutputStream());
            document.open();

            Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18);
            Paragraph title = new Paragraph("📘 Book Information\n\n", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/book_management", "root", "Gautam@1234");

            PreparedStatement ps = con.prepareStatement("SELECT * FROM books WHERE id=?");
            ps.setInt(1, bookId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                PdfPTable table = new PdfPTable(2);
                table.setSpacingBefore(10f);

                table.addCell("ID");
                table.addCell(String.valueOf(rs.getInt("id")));

                table.addCell("Title");
                table.addCell(rs.getString("title"));

                table.addCell("Author");
                table.addCell(rs.getString("author"));

                table.addCell("ISBN");
                table.addCell(rs.getString("isbn"));

                document.add(table);
            }

            con.close();

            Paragraph footer = new Paragraph("\nDownloaded by: " + downloadedBy,
                    FontFactory.getFont(FontFactory.HELVETICA_OBLIQUE, 12, BaseColor.GRAY));
            footer.setAlignment(Element.ALIGN_RIGHT);
            document.add(footer);

            document.close();

        } catch (Exception e) {
            e.printStackTrace();
            res.setContentType("text/html");
            res.getWriter().println("<h3>Error: " + e.getMessage() + "</h3>");
        }
    }
}

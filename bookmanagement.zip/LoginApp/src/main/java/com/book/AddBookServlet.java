package com.book;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;

public class AddBookServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

        System.out.println("📌 AddBookServlet called");
        HttpSession session = req.getSession(false);

        if (session == null) {
            System.out.println("⚠️ No session, redirecting to login.jsp");
            res.sendRedirect("login.jsp");
            return;
        }

        String role = (String) session.getAttribute("role");
        System.out.println("Session: " + session.getId());
        System.out.println("Role from session: " + role);

        if (role == null || !role.equals("admin")) {
            System.out.println("⚠️ Invalid role or missing, redirecting to login.jsp");
            res.sendRedirect("login.jsp");
            return;
        }

        String title = req.getParameter("title");
        String author = req.getParameter("author");
        String isbn = req.getParameter("isbn");

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/book_management", "root", "Gautam@1234");

 
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO books (title, author, isbn) VALUES (?, ?, ?)");
            ps.setString(1, title);
            ps.setString(2, author);
            ps.setString(3, isbn);

            int rows = ps.executeUpdate();
            con.close();

            if (rows > 0) {
                System.out.println("✅ Book added successfully: " + title);
   
                res.sendRedirect("admin_dashboard.jsp?book_added=1");
            } else {
                System.out.println("⚠️ Book insert failed");
                res.sendRedirect("admin_dashboard.jsp?book_added=0");
            }

        } catch (Exception e) {
            e.printStackTrace();
            res.setContentType("text/html");
            res.getWriter().println("Error: " + e.getMessage());
        }
    }
}
